fx_version 'adamant'
games { 'gta5' }


author 'TheRealElchapo'
version '1.0.0'
lua54 'yes'

description 'FiveM Gun Powder Test Script'

shared_script 'config.lua'
client_script 'client/*.lua'
server_script 'server/*.lua'

escrow_ignore {
    'config.lua'
}