local gprTimer = 0
local gprPositive = false
local plyPed = PlayerPedId()
local TestDistance = 5
Citizen.CreateThread(function()
    while true do
        Citizen.Wait(1)
        GPRThread()
    end
end)

if Config.CleanGunPowderResidue then
    RegisterCommand(Config.Clean, function()
        if gprPositive then
            gprPositive = false
            gprTimer = 0
            Notify(Config.Text.TCleaningGPR)
        elseif not gprPositive then
            Notify(Config.Text.AlreadyClean)
        end
        print('Cleaned GPR')
    end)
end


RegisterCommand(Config.Test, function()
    local playerCoords = GetEntityCoords(plyPed)
    for _, player in ipairs(GetActivePlayers()) do
        local targetPed = GetPlayerPed(player)
        local targetId = GetPlayerServerId(player)
        local distance = #(playerCoords-GetEntityCoords(targetPed))
        if targetPed ~= plyPed then
            if distance <= TestDistance then
                print('GPR Tested: ' .. targetId)
                TriggerServerEvent('GPR:TestPlayer', targetId)
            else
                Notify(tostring(Config.Text.NoSubjectError))
            end
        end
    end
end)

RegisterCommand('gprs', function()
    if psrPositive then
        Notify('You Tested ^1Positive')
    elseif not gprPositive then
        Notify('You Tested ^2Negative')
    end
end)

RegisterNetEvent("GPR:TestNotify")
AddEventHandler("GPR:TestNotify", function(notHandler)
    Notify(notHandler)
end)

RegisterNetEvent("GPR:TestHandler")
AddEventHandler("GPR:TestHandler", function(tester)
    if gprPositive then
        TriggerServerEvent("GPR:TestCallback", tester, true)
    elseif not gprPositive then
        TriggerServerEvent("GPR:TestCallback", tester, false)
    end
end)

function GPRThread()
    plyPed = PlayerPedId()
    if IsPedShooting(plyPed) then
        if gprPositive then
            gprTimer = Config.AutoClean
        else
            gprPositive = true
            gprTimer = Config.AutoClean
            Citizen.CreateThread(GPRThreadTimer)
        end
    end
end

function GPRThreadTimer()
    while gprPositive do
        Citizen.Wait(1000)
        if gprTimer == 0 then
            gprPositive = false
        else
            gprTimer = gprTimer - 1
        end
    end
end

function Notify(text)
    TriggerEvent('chat:addMessage', {
        color = { 255, 0, 0},
        multiline = true,
        args = {'GPR', text}
    })      
end


--I just wanted to test githubs new online editor