RegisterNetEvent("GPR:TestPlayer")
AddEventHandler("GPR:TestPlayer", function(tested)
    TriggerClientEvent("GPR:TestHandler", tested, source)
    if Config.NotifPlayer then
        TriggerClientEvent("GPR:TestNotify", tested, Config.Text.GettingTestedMsg .. GetPlayerName(source))
    end
end)

RegisterNetEvent("GPR:TestCallback")
AddEventHandler("GPR:TestCallback", function(tester, result)
    if result then
        TriggerClientEvent("GPR:TestNotify", tester, Config.Text.TestedPositive)
    else
        TriggerClientEvent("GPR:TestNotify", tester, Config.Text.TestedNegative)
    end
end)