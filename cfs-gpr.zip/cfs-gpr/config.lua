Config = {
    NotifPlayer = true, -- Set to false to not notify player
    CleanGunPowderResidue = true, -- Set to false to not allow players to clean off residue

    Test = "gpr", -- command to test 
    Clean = "cleangpr", -- Command To clean player

    AutoClean = 900, -- IN SECONDS ammount of time in seconds default 15 mins
    TestDistance = 3, -- max distance for test to work

    Text = {
        GettingTestedMsg = "^3You Have Been Tested For GPR By: ^2",
        TestedPositive = "Subject Tested ^1Positive ^rGPR",
        TestedNegative = "Subject Tested ^2Negative ^rGPR",
        AlreadyClean = "^3You Are Already Clean",
        TCleaningGPR = "^2You Cleaned Gunshot Power Offs",
        NoSubjectError = "^3Could Not Find Player",
    },
}